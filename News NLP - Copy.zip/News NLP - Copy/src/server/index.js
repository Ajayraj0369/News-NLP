const dotenv = require("dotenv");
dotenv.config({ path: "../../.env" });
const path = require("path");
const express = require("express");
const mockAPIResponse = require("./mockAPI.js");
const bodyParser = require("body-parser");
var AYLIENTextAPI = require("aylien_textapi");

const app = express();
const cors = require("cors");
app.use(cors());
app.options("*", cors());

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());

var textapi = new AYLIENTextAPI({
  application_id: process.env.API_ID,
  application_key: process.env.API_KEY,
});

app.use(express.static("dist"));

console.log(__dirname);

app.get("/", function (req, res) {
  res.sendFile("/index.html", { root: "dist" });
});

// designates what port the app will listen to for incoming requests
app.listen(5700, function () {
  console.log("Example app listening on port 5700!");
});

// app.get("/test", function (req, res) {
//   res.send(mockAPIResponse);
// });

app.post("/test", testURL);

function testURL(req, res) {
  console.log(req.body.url);
  textapi.classify(
    {
      url: req.body.url,
    },
    function (error, response) {
      // if (error === null) {
      res.send(response);
      // response["categories"].forEach(function (c) {
      //   res.send(response);
      console.log(response);
    }
  );
  // } else {
  //   console.log(error);
  // }
}
