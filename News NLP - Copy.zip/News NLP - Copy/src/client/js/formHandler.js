export function handleSubmit(event) {
  event.preventDefault();

  let expression = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
  let regex = new RegExp(expression);

  // check what text was put into the form field
  let formText = document.getElementById("name").value;

  console.log(formText);

  var res = "";
  if (formText.match(regex)) {
    res = "Valid URL";
    console.log(res);

    // fetch("https://api.github.com/users")
    // postData("/", { url: "formText" })
    fetch("http://localhost:5700/test", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: `${formText}`,
      }),
    })
      // try {
      //   const newData = await response.json();
      //   return newData;
      // } catch (error) {
      //   console.log("Incorrect pincode ", error);
      // }

      .then((res) => res.json())
      .then(function (res) {
        document.getElementById(
          "results"
        ).innerHTML = `Language : ${res.language}`;
        // document.getElementById(
        //   "label"
        // ).innerHTML = `Category: ${res.categories[0].label}`;
        document.getElementById("text").innerHTML = res.text;
      });
  } else {
    res = "Invalid URL";
    console.log(res);
    document.getElementById(
      "results"
    ).innerHTML = `Kindly provide a correct URL`;
  }
}
